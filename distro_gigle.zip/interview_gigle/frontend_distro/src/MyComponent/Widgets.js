
import * as WidgetCarousel from './WidgetCarousel/carousel'
import * as WidgetButton from './WidgetButton/button'
import * as WidgetCard from './WidgetCard/Card'
import * as WidgetFooter from './WidgetFooter/Footer'

export { WidgetCarousel, WidgetButton, WidgetCard, WidgetFooter }