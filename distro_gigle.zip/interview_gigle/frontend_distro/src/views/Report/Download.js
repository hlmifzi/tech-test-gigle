const Download = () => {
    window.print()
}

export default Download